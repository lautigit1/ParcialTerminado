package com.example;

import com.example.dao.CategoriaDAOImpl;
import com.example.dao.ProductoDAOImpl;
import com.example.model.Categoria;
import com.example.model.Producto;
import com.example.util.Databaseutil;
import com.example.util.Databaseutil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Logger logger = LogManager.getLogger(Main.class);

    public static void main(String[] args) {
        // Inicializar base de datos
        Databaseutil.initDatabase();

        Scanner scanner = new Scanner(System.in);
        ProductoDAOImpl productoDAO = new ProductoDAOImpl();
        CategoriaDAOImpl categoriaDAO = new CategoriaDAOImpl();

        logger.info("Aplicación iniciada");

        while (true) {
            System.out.println("\n--- MENÚ PRINCIPAL ---");
            System.out.println("1. Gestión de Productos");
            System.out.println("2. Gestión de Categorías");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            String opcionPrincipal = scanner.nextLine();

            try {
                switch (opcionPrincipal) {
                    case "1":
                        menuProductos(scanner, productoDAO);
                        break;
                    case "2":
                        menuCategorias(scanner, categoriaDAO);
                        break;
                    case "0":
                        System.out.println("Saliendo...");
                        logger.info("Aplicación finalizada.");
                        return;
                    default:
                        System.out.println("Opción no válida.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                logger.error("Error de ejecución: ", e);
            }
        }
    }

    private static void menuProductos(Scanner scanner, ProductoDAOImpl productoDAO) {
        while (true) {
            System.out.println("\n--- MENÚ PRODUCTOS ---");
            System.out.println("1. Crear producto");
            System.out.println("2. Listar productos");
            System.out.println("3. Buscar producto por ID");
            System.out.println("4. Actualizar producto");
            System.out.println("5. Eliminar producto");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            String opcion = scanner.nextLine();

            try {
                switch (opcion) {
                    case "1":
                        crearProducto(scanner, productoDAO);
                        break;
                    case "2":
                        listarProductos(productoDAO);
                        break;
                    case "3":
                        buscarProductoPorId(scanner, productoDAO);
                        break;
                    case "4":
                        actualizarProducto(scanner, productoDAO);
                        break;
                    case "5":
                        eliminarProducto(scanner, productoDAO);
                        break;
                    case "0":
                        return;
                    default:
                        System.out.println("Opción no válida.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                logger.error("Error en menú productos: ", e);
            }
        }
    }

    private static void eliminarProducto(Scanner scanner, ProductoDAOImpl productoDAO) {
    }

    private static void buscarProductoPorId(Scanner scanner, ProductoDAOImpl productoDAO) {
    }

    private static void actualizarProducto(Scanner scanner, ProductoDAOImpl productoDAO) {
    }

    private static void menuCategorias(Scanner scanner, CategoriaDAOImpl categoriaDAO) {
        while (true) {
            System.out.println("\n--- MENÚ CATEGORÍAS ---");
            System.out.println("1. Crear categoría");
            System.out.println("2. Listar categorías");
            System.out.println("3. Buscar categoría por ID");
            System.out.println("4. Actualizar categoría");
            System.out.println("5. Eliminar categoría");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");

            String opcion = scanner.nextLine();

            try {
                switch (opcion) {
                    case "1":
                        crearCategoria(scanner, categoriaDAO);
                        break;
                    case "2":
                        listarCategorias(categoriaDAO);
                        break;
                    case "3":
                        buscarCategoriaPorId(scanner, categoriaDAO);
                        break;
                    case "4":
                        actualizarCategoria(scanner, categoriaDAO);
                        break;
                    case "5":
                        eliminarCategoria(scanner, categoriaDAO);
                        break;
                    case "0":
                        return;
                    default:
                        System.out.println("Opción no válida.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                logger.error("Error en menú categorías: ", e);
            }
        }
    }

    private static void crearCategoria(Scanner scanner, CategoriaDAOImpl categoriaDAO) {
        System.out.print("Nombre de la categoría: ");
        String nombre = scanner.nextLine();

        Categoria nueva = new Categoria(nombre);
        int id = categoriaDAO.crear(nueva);

        if (id > 0) {
            System.out.println("Categoría creada con ID: " + id);
            logger.info("Categoría creada: {}", nueva.getNombre());
        } else {
            System.out.println("Error al crear categoría.");
            logger.error("Falló la creación de la categoría.");
        }
    }

    private static void listarCategorias(CategoriaDAOImpl categoriaDAO) {
        List<Categoria> categorias = categoriaDAO.listarTodos();
        if (categorias.isEmpty()) {
            System.out.println("No hay categorías registradas.");
        } else {
            System.out.println("\n--- LISTA DE CATEGORÍAS ---");
            categorias.forEach(System.out::println);
        }
        logger.info("Listado de categorías mostrado.");
    }

    private static void buscarCategoriaPorId(Scanner scanner, CategoriaDAOImpl categoriaDAO) {
        System.out.print("ID de la categoría a buscar: ");
        int id = validarInt(scanner.nextLine());

        Categoria encontrada = categoriaDAO.buscarPorId(id);
        if (encontrada != null) {
            System.out.println(encontrada);
            logger.info("Categoría encontrada: {}", encontrada.getNombre());
        } else {
            System.out.println("No existe la categoría con ID: " + id);
            logger.warn("Intento fallido de buscar categoría ID: {}", id);
        }
    }

    private static void actualizarCategoria(Scanner scanner, CategoriaDAOImpl categoriaDAO) {
        System.out.print("ID de la categoría a actualizar: ");
        int id = validarInt(scanner.nextLine());

        Categoria actual = categoriaDAO.buscarPorId(id);
        if (actual == null) {
            System.out.println("No existe la categoría con ID: " + id);
            return;
        }

        System.out.print("Nuevo nombre (" + actual.getNombre() + "): ");
        String nuevoNombre = scanner.nextLine();
        if (!nuevoNombre.isEmpty()) {
            actual.setNombre(nuevoNombre);
        }

        if (categoriaDAO.actualizar(actual)) {
            System.out.println("Categoría actualizada correctamente");
            logger.info("Categoría actualizada ID: {}", id);
        } else {
            System.out.println("Error al actualizar la categoría");
            logger.error("Fallo al actualizar categoría ID: {}", id);
        }
    }

    private static void eliminarCategoria(Scanner scanner, CategoriaDAOImpl categoriaDAO) {
        System.out.print("ID de la categoría a eliminar: ");
        int id = validarInt(scanner.nextLine());

        if (categoriaDAO.eliminar(id)) {
            System.out.println("Categoría eliminada correctamente");
            logger.warn("Categoría eliminada ID: {}", id);
        } else {
            System.out.println("Error al eliminar la categoría o no existe");
            logger.error("Fallo al eliminar categoría ID: {}", id);
        }
    }

    // Métodos para productos (los que ya tenías)...
    private static void crearProducto(Scanner scanner, ProductoDAOImpl productoDAO) {
        // ... (tu implementación existente)
    }

    private static void listarProductos(ProductoDAOImpl productoDAO) {
        // ... (tu implementación existente)
    }

    // ... (otros métodos de productos)

    private static int validarInt(String input) {
        try {
            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Debe ingresar un número entero válido");
        }
    }
}