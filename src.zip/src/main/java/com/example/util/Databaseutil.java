package com.example.util;

import java.sql.*;

public class Databaseutil {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "";
    private static final String DB_NAME = "tienda";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL + DB_NAME, DB_USER, DB_PASSWORD);
    }

    public static void initDatabase() {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             Statement stmt = conn.createStatement()) {

            stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS " + DB_NAME);

            try (Connection connTienda = getConnection();
                 Statement stmtTienda = connTienda.createStatement()) {

                String sqlCategorias = "CREATE TABLE IF NOT EXISTS categorias (" +
                        "id INT AUTO_INCREMENT PRIMARY KEY, " +
                        "nombre VARCHAR(100) NOT NULL)";

                String sqlProductos = "CREATE TABLE IF NOT EXISTS productos (" +
                        "id INT AUTO_INCREMENT PRIMARY KEY, " +
                        "nombre VARCHAR(100) NOT NULL, " +
                        "descripcion TEXT, " +
                        "precio DECIMAL(10,2) NOT NULL, " +
                        "stock INT NOT NULL)";

                stmtTienda.executeUpdate(sqlCategorias);
                stmtTienda.executeUpdate(sqlProductos);

                System.out.println("Base de datos y tablas inicializadas correctamente");
            }
        } catch (SQLException e) {
            System.err.println("Error al inicializar la base de datos:");
            e.printStackTrace();
        }
    }

    public static void closeResources(AutoCloseable... resources) {
        for (AutoCloseable resource : resources) {
            if (resource != null) {
                try {
                    resource.close();
                } catch (Exception e) {
                    System.err.println("Error al cerrar recurso:");
                    e.printStackTrace();
                }
            }
        }
    }
}